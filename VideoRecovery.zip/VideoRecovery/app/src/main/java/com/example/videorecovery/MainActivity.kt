package com.example.videorecovery

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.text.format.Formatter
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {

    // file != null  -> .trashed-/recycle file on disk (copy it out)
    // uri  != null  -> MediaStore trashed item (un-trash it)
    data class Item(
        val name: String,
        val size: Long,
        val modifiedMs: Long,
        val source: String,
        val file: File? = null,
        val uri: Uri? = null
    )

    private val items = mutableListOf<Item>()
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var scanBtn: Button
    private val videoExt = setOf("mp4", "mkv", "3gp", "mov", "webm", "avi")
    private val REQ_TRASH = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        status = TextView(this).apply { text = "Scan chalu korar jonno button e chap dao"; textSize = 15f }
        scanBtn = Button(this).apply { text = "Scan koro"; setOnClickListener { startScan() } }
        val restoreBtn = Button(this).apply { text = "Select kora video Restore koro"; setOnClickListener { restoreSelected() } }
        list = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(status)
        root.addView(scanBtn)
        root.addView(restoreBtn)
        root.addView(list)
        setContentView(root)
    }

    private fun hasAllFilesAccess() = Environment.isExternalStorageManager()

    private fun askAllFilesAccess() {
        Toast.makeText(this, "\"All files access\" permission on koro, tarpor back e ese abar Scan koro", Toast.LENGTH_LONG).show()
        val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
        startActivity(i)
    }

    private fun startScan() {
        if (!hasAllFilesAccess()) { askAllFilesAccess(); return }
        scanBtn.isEnabled = false
        status.text = "Scan hocche..."
        Thread {
            val found = mutableListOf<Item>()
            found += scanMediaStoreTrash()
            val known = found.map { it.name }.toSet()
            found += scanFiles().filter { it.name !in known }
            found.sortByDescending { it.modifiedMs }
            runOnUiThread {
                items.clear(); items.addAll(found)
                val labels = items.map {
                    "${it.name}\n${Formatter.formatShortFileSize(this, it.size)} • " +
                        "${DateFormat.getDateTimeInstance().format(Date(it.modifiedMs))} • ${it.source}"
                }
                list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, labels)
                status.text = if (items.isEmpty())
                    "Kono video paoa jayni. Phone er Trash/Google Photos Bin ar check koro."
                else "${items.size} ta video paoa gese. Select kore Restore koro."
                scanBtn.isEnabled = true
            }
        }.start()
    }

    /** Android 11+ MediaStore Trash (30 din porjonto thake) */
    private fun scanMediaStoreTrash(): List<Item> {
        val out = mutableListOf<Item>()
        val args = Bundle().apply {
            putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
        }
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED
        )
        try {
            contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, args, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out += Item(
                        name = c.getString(1) ?: "video_$id",
                        size = c.getLong(2),
                        modifiedMs = c.getLong(3) * 1000,
                        source = "Gallery Trash",
                        uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    )
                }
            }
        } catch (_: Exception) { }
        return out
    }

    /** .trashed- file, recycle/trash folder, ar screen recorder folder scan */
    private fun scanFiles(): List<Item> {
        val out = mutableListOf<Item>()
        val root = Environment.getExternalStorageDirectory()
        root.walkTopDown()
            .onEnter { dir -> !(dir.parentFile == root && dir.name == "Android") }
            .filter { it.isFile && it.extension.lowercase() in videoExt && it.length() > 0 }
            .forEach { f ->
                val p = f.absolutePath.lowercase()
                val src = when {
                    f.name.startsWith(".trashed-") -> "Trashed file"
                    "/.trash" in p || "recycle" in p || "/.deleted" in p -> "Trash folder"
                    "screenrecord" in p || "screen recorder" in p || "screen_record" in p -> "Screen recorder folder"
                    else -> null
                }
                if (src != null) out += Item(f.name, f.length(), f.lastModified(), src, file = f)
            }
        return out
    }

    private fun restoreSelected() {
        val checked = list.checkedItemPositions
        val chosen = (0 until items.size).filter { checked.get(it) }.map { items[it] }
        if (chosen.isEmpty()) { Toast.makeText(this, "Age video select koro", Toast.LENGTH_SHORT).show(); return }

        // 1) MediaStore trash: user confirm dialog diye un-trash
        val uris = chosen.mapNotNull { it.uri }
        if (uris.isNotEmpty()) {
            val pi = MediaStore.createTrashRequest(contentResolver, uris, false)
            startIntentSenderForResult(pi.intentSender, REQ_TRASH, null, 0, 0, 0)
        }

        // 2) File based: Movies/Recovered e copy
        val files = chosen.filter { it.file != null }
        if (files.isNotEmpty()) {
            Thread {
                var ok = 0
                files.forEach { if (copyOut(it)) ok++ }
                runOnUiThread {
                    Toast.makeText(this, "$ok/${files.size} ta file Movies/Recovered e rakha hoyeche", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
    }

    private fun copyOut(item: Item): Boolean = try {
        val cleanName = item.name.replace(Regex("^\\.trashed-\\d+-"), "")
        val mime = when (cleanName.substringAfterLast('.').lowercase()) {
            "mkv" -> "video/x-matroska"
            "3gp" -> "video/3gpp"
            "webm" -> "video/webm"
            "mov" -> "video/quicktime"
            "avi" -> "video/x-msvideo"
            else -> "video/mp4"
        }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, cleanName)
            put(MediaStore.Video.Media.MIME_TYPE, mime)
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Recovered")
        }
        val dst = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        if (dst == null) false else {
            contentResolver.openOutputStream(dst)?.use { out ->
                FileInputStream(item.file).use { it.copyTo(out) }
            }
            true
        }
    } catch (e: Exception) { false }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_TRASH && resultCode == RESULT_OK)
            Toast.makeText(this, "Trash theke video Gallery te fire esheche", Toast.LENGTH_LONG).show()
    }
}
